//o que depois vai virar html

import { useState } from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import { cores } from './src/theme';
import BoasVindasScreen from './src/screens/BoasVindasScreen';
import ComoContinuarScreen from './src/screens/ComoContinuarScreen';
import LoginScreen from './src/screens/LoginScreen';
import CadastroScreen from './src/screens/CadastroScreen';
import InicioScreen from './src/screens/InicioScreen';
import SobreScreen from './src/screens/SobreScreen';
import PontosColetaScreen from './src/screens/PontosColetaScreen';
import EducacaoScreen from './src/screens/EducacaoScreen';
import ForumScreen from './src/screens/ForumScreen';
import PerfilScreen from './src/screens/PerfilScreen';
import CadastroPontoScreen from './src/screens/CadastroPontoScreen';
import AprovacaoPontosScreen from './src/screens/AprovacaoPontosScreen';
import HistoricoEntregasScreen from './src/screens/HistoricoEntregasScreen';
import ChatListaScreen from './src/screens/ChatListaScreen';
import ChatConversaScreen from './src/screens/ChatConversaScreen';

const AuthStack = createNativeStackNavigator();
const AppStack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// cabeçalho rosa claro, como no protótipo
const cabecalho = {
  headerStyle: { backgroundColor: cores.rosaMedio },
  headerTintColor: cores.rosaTitulo,
  headerTitleStyle: { fontWeight: 'bold', color: cores.rosaTitulo },
  headerShadowVisible: false,
};

// Boas-vindas, "Como deseja continuar?", Login e Cadastro
function FluxoLogin({ onEntrar }) {
  return (
    <AuthStack.Navigator initialRouteName="BoasVindas" screenOptions={{ headerShown: false }}>
      <AuthStack.Screen name="BoasVindas" component={BoasVindasScreen} />
      <AuthStack.Screen name="ComoContinuar" component={ComoContinuarScreen} />
      <AuthStack.Screen name="Login">
        {(props) => <LoginScreen {...props} onEntrar={onEntrar} />}
      </AuthStack.Screen>
      <AuthStack.Screen name="Cadastro">
        {(props) => <CadastroScreen {...props} onEntrar={onEntrar} />}
      </AuthStack.Screen>
    </AuthStack.Navigator>
  );
}

// ícone de perfil no topo
function BotaoPerfil({ onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={estilos.perfilBtn}>
      <Ionicons name="person-circle-outline" size={30} color={cores.rosaTitulo} />
    </TouchableOpacity>
  );
}

// abas do app
function Abas({ usuario }) {
  return (
    <Tab.Navigator
      screenOptions={({ route, navigation }) => ({
        ...cabecalho,
        headerRight: () => <BotaoPerfil onPress={() => navigation.navigate('Perfil')} />,
        tabBarActiveTintColor: cores.rosa,
        tabBarInactiveTintColor: '#C9A3B5',
        tabBarStyle: {
          height: 64,
          paddingBottom: 8,
          paddingTop: 6,
          backgroundColor: '#FFF5F9',
          borderTopWidth: 0,
          borderTopLeftRadius: 24,
          borderTopRightRadius: 24,
          elevation: 8,
          shadowColor: '#C2185B',
          shadowOpacity: 0.12,
          shadowRadius: 10,
          shadowOffset: { width: 0, height: -3 },
        },
        tabBarLabelStyle: { fontSize: 10, fontWeight: '600' },
        tabBarIcon: ({ color, size }) => {
          const icones = {
            Início: 'home',
            Sobre: 'information-circle',
            Pontos: 'location',
            Educação: 'book',
            Chat: 'chatbubble-ellipses',
            Fórum: 'chatbubbles',
          };
          return <Ionicons name={icones[route.name]} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Início" component={InicioScreen} />
      <Tab.Screen name="Sobre" component={SobreScreen} />
      <Tab.Screen name="Pontos" options={{ title: 'Pontos de Coleta' }}>
        {(props) => <PontosColetaScreen {...props} usuario={usuario} />}
      </Tab.Screen>
      <Tab.Screen name="Educação" component={EducacaoScreen} />
      {(usuario.tipo === 'doadora' || usuario.tipo === 'beneficiaria') && (
        <Tab.Screen name="Chat">
          {(props) => <ChatListaScreen {...props} usuario={usuario} />}
        </Tab.Screen>
      )}
      <Tab.Screen name="Fórum">
        {(props) => <ForumScreen {...props} usuario={usuario} />}
      </Tab.Screen>
    </Tab.Navigator>
  );
}

// abas + tela de Perfil por cima
function FluxoApp({ usuario, onSair, onTrocar }) {
  return (
    <AppStack.Navigator>
      <AppStack.Screen name="Abas" options={{ headerShown: false }}>
        {() => <Abas usuario={usuario} />}
      </AppStack.Screen>
      <AppStack.Screen
        name="CadastroPonto"
        options={{ title: 'Novo ponto de coleta', ...cabecalho }}
      >
        {(props) => <CadastroPontoScreen {...props} usuario={usuario} />}
      </AppStack.Screen>
      <AppStack.Screen
        name="HistoricoEntregas"
        options={{ title: 'Minhas doações', ...cabecalho }}
      >
        {(props) => <HistoricoEntregasScreen {...props} usuario={usuario} />}
      </AppStack.Screen>
      <AppStack.Screen
        name="AprovacaoPontos"
        options={{ title: 'Aprovar pontos', ...cabecalho }}
      >
        {(props) => <AprovacaoPontosScreen {...props} usuario={usuario} />}
      </AppStack.Screen>
      <AppStack.Screen
        name="Conversa"
        options={({ route }) => ({
          title: route.params?.nome || 'Conversa',
          ...cabecalho,
        })}
      >
        {(props) => <ChatConversaScreen {...props} usuario={usuario} />}
      </AppStack.Screen>
      <AppStack.Screen
        name="Perfil"
        options={{ title: 'Perfil', ...cabecalho }}
      >
        {(props) => <PerfilScreen {...props} usuario={usuario} onSair={onSair} onTrocar={onTrocar} />}
      </AppStack.Screen>
    </AppStack.Navigator>
  );
}

export default function App() {
  const [usuario, setUsuario] = useState(null);

  return (
    <NavigationContainer>
      <StatusBar style="dark" />
      {usuario ? (
        // key: ao trocar de perfil (doadora/beneficiária), o app recomeça nas abas já com o novo perfil
        <FluxoApp
          key={usuario.id_usuario}
          usuario={usuario}
          onSair={() => setUsuario(null)}
          onTrocar={setUsuario}
        />
      ) : (
        <FluxoLogin onEntrar={setUsuario} />
      )}
    </NavigationContainer>
  );
}

const estilos = StyleSheet.create({
  perfilBtn: {
    marginRight: 14,
  },
});
