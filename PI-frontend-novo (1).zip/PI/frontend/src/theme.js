// Paleta do protótipo "Protótipo-CW" (Figma). Mude as cores do app todo aqui.
export const cores = {
  // principais
  rosa: '#F0508C',         // botões e destaques
  rosaForte: '#FF6FA4',    // blocos grandes (cabeçalho do cadastro, card do login)
  rosaEscuro: '#D0246E',   // botão escuro ("Entrar")
  rosaMedio: '#FFB4D5',    // cabeçalhos e botões claros
  rosaClaro: '#FFEAF2',    // fundo das telas
  rosaFundo: '#FFDBE7',    // fundo das telas de entrada
  rosaCorpo: '#FFC8DB',    // corpo da tela de cadastro
  rosaCampo: '#FFD3E4',    // campos de texto
  rosaTitulo: '#9C2F68',   // títulos sobre fundo rosa

  // neutros
  branco: '#FFFFFF',
  texto: '#4A1D36',
  textoClaro: '#7A5668',
  placeholder: '#B07A93',
  borda: '#FFC2DB',

  // status
  verde: '#16A34A',
  vermelho: '#B00020',
};

export const espaco = {
  pequeno: 8,
  medio: 16,
  grande: 24,
};

export const raio = {
  pill: 999,
  cartao: 22,
  bloco: 36,
};

// sombra suave dos cards (funciona no celular e na web)
export const sombra = {
  shadowColor: '#C2185B',
  shadowOpacity: 0.12,
  shadowRadius: 12,
  shadowOffset: { width: 0, height: 4 },
  elevation: 3,
};
