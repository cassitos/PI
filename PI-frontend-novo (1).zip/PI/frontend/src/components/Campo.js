import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { cores, raio } from '../theme';

// semRotulo: usa só o texto de dentro do campo (como no protótipo)
// sobreRosa: campo translúcido para usar em cima de blocos rosa
// icone: ícone fixo no fim do campo (ex.: 'person', 'mail'); em senha vira o "olhinho"
export default function Campo({
  rotulo,
  valor,
  aoMudar,
  placeholder,
  tipoTeclado,
  senha,
  icone,
  semRotulo,
  sobreRosa,
}) {
  const [ver, setVer] = useState(false);

  return (
    <View style={estilos.grupo}>
      {!semRotulo && <Text style={estilos.rotulo}>{rotulo}</Text>}
      <View style={[estilos.caixa, sobreRosa && estilos.caixaSobreRosa]}>
        <TextInput
          style={estilos.input}
          value={valor}
          onChangeText={aoMudar}
          placeholder={placeholder}
          placeholderTextColor={sobreRosa ? '#9C3A68' : cores.placeholder}
          keyboardType={tipoTeclado}
          secureTextEntry={senha && !ver}
          autoCapitalize="none"
          accessibilityLabel={rotulo || placeholder}
        />
        {senha ? (
          <TouchableOpacity
            onPress={() => setVer(!ver)}
            accessibilityLabel={ver ? 'Ocultar senha' : 'Mostrar senha'}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Ionicons name={ver ? 'eye-outline' : 'eye-off-outline'} size={20} color={cores.rosaTitulo} />
          </TouchableOpacity>
        ) : icone ? (
          <Ionicons name={icone} size={20} color={cores.rosaTitulo} />
        ) : null}
      </View>
    </View>
  );
}

const estilos = StyleSheet.create({
  grupo: { marginBottom: 14 },
  rotulo: {
    fontSize: 13,
    fontWeight: '600',
    color: cores.rosaTitulo,
    marginBottom: 6,
    marginLeft: 12,
  },
  caixa: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: cores.rosaCampo,
    borderRadius: raio.pill,
    paddingHorizontal: 18,
    minHeight: 46,
  },
  caixaSobreRosa: { backgroundColor: 'rgba(255,255,255,0.38)' },
  input: {
    flex: 1,
    fontSize: 15,
    color: cores.texto,
    paddingVertical: 11,
    // tira o contorno padrão do navegador (só na web)
    ...Platform.select({ web: { outlineStyle: 'none' } }),
  },
});
