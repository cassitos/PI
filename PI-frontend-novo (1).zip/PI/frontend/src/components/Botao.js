import { Text, TouchableOpacity, StyleSheet } from 'react-native';
import { cores, raio } from '../theme';

// tipo: 'cheio' (rosa) | 'contorno' | 'claro' (rosa claro) | 'escuro'
export default function Botao({ titulo, onPress, tipo = 'cheio', estilo, desabilitado }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={desabilitado}
      activeOpacity={0.8}
      accessibilityRole="button"
      style={[estilos.base, estilos[tipo] || estilos.cheio, desabilitado && estilos.desabilitado, estilo]}
    >
      <Text style={[estilos.texto, tipo === 'contorno' && estilos.textoContorno]}>{titulo}</Text>
    </TouchableOpacity>
  );
}

const estilos = StyleSheet.create({
  base: {
    paddingVertical: 13,
    paddingHorizontal: 24,
    borderRadius: raio.pill,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#C2185B',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  cheio: { backgroundColor: cores.rosa },
  escuro: { backgroundColor: cores.rosaEscuro },
  claro: { backgroundColor: cores.rosaMedio },
  contorno: {
    backgroundColor: cores.branco,
    borderWidth: 1.5,
    borderColor: cores.rosa,
  },
  desabilitado: { opacity: 0.6 },
  texto: {
    color: cores.branco,
    fontSize: 16,
    fontWeight: 'bold',
  },
  textoContorno: { color: cores.rosa },
});
