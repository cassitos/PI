import { Image } from 'react-native';

// Abby, a mascote do Connected Woman (arte original, PNG com fundo transparente).
// Para trocar a arte, substitua src/img/abby.png mantendo o mesmo nome.
const ABBY = require('../img/abby.png');

const PROPORCAO = 592 / 790; // largura / altura da imagem

// "pose" é aceito só por compatibilidade com as telas; a imagem é sempre a mesma.
export default function Abby({ altura = 160, estilo }) {
  return (
    <Image
      source={ABBY}
      accessibilityLabel="Abby, a mascote do Connected Woman"
      resizeMode="contain"
      style={[{ height: altura, width: altura * PROPORCAO }, estilo]}
    />
  );
}
