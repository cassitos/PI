import { View, Text, StyleSheet } from 'react-native';
import Abby from './Abby';
import { cores, raio } from '../theme';

// Faixa rosa com título e a Abby, igual à tela "Locais de doação" do protótipo.
export default function CabecalhoTela({ titulo, subtitulo, pose = 'aponta' }) {
  return (
    <View style={estilos.faixa}>
      <View style={estilos.textos}>
        <Text style={estilos.titulo}>{titulo}</Text>
        {!!subtitulo && <Text style={estilos.subtitulo}>{subtitulo}</Text>}
      </View>
      <Abby pose={pose} altura={104} estilo={estilos.abby} />
    </View>
  );
}

const estilos = StyleSheet.create({
  faixa: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: cores.rosaMedio,
    borderBottomLeftRadius: raio.bloco,
    borderBottomRightRadius: raio.bloco,
    paddingLeft: 22,
    paddingRight: 14,
    paddingTop: 6,
    paddingBottom: 14,
  },
  textos: { flex: 1, paddingRight: 8 },
  titulo: { fontSize: 24, fontWeight: 'bold', color: cores.rosaTitulo },
  subtitulo: { fontSize: 13, color: cores.texto, marginTop: 4, lineHeight: 18 },
  abby: { marginTop: 4 },
});
