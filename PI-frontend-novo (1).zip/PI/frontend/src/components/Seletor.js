import { useState } from 'react';
import { View, Text, TouchableOpacity, Modal, FlatList, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { cores, raio } from '../theme';

export default function Seletor({ rotulo, valor, opcoes, aoEscolher, placeholder, semRotulo }) {
  const [aberto, setAberto] = useState(false);

  return (
    <View style={estilos.grupo}>
      {!semRotulo && <Text style={estilos.rotulo}>{rotulo}</Text>}

      <TouchableOpacity
        style={estilos.caixa}
        onPress={() => setAberto(true)}
        accessibilityRole="button"
        accessibilityLabel={rotulo}
      >
        <Text style={[estilos.textoCaixa, !valor && estilos.placeholder]}>
          {valor || placeholder || rotulo}
        </Text>
        <Ionicons name="chevron-down" size={20} color={cores.rosaTitulo} />
      </TouchableOpacity>

      <Modal visible={aberto} transparent animationType="fade" onRequestClose={() => setAberto(false)}>
        <TouchableOpacity style={estilos.fundo} activeOpacity={1} onPress={() => setAberto(false)}>
          <View style={estilos.janela}>
            <Text style={estilos.tituloJanela}>{rotulo}</Text>
            <FlatList
              data={opcoes}
              keyExtractor={(item) => item}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[estilos.opcao, item === valor && estilos.opcaoAtiva]}
                  onPress={() => {
                    aoEscolher(item);
                    setAberto(false);
                  }}
                >
                  <Text style={[estilos.textoOpcao, item === valor && estilos.textoOpcaoAtiva]}>{item}</Text>
                </TouchableOpacity>
              )}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const estilos = StyleSheet.create({
  grupo: { marginBottom: 14 },
  rotulo: {
    fontSize: 13,
    fontWeight: '600',
    color: cores.rosaTitulo,
    marginBottom: 6,
    marginLeft: 12,
  },
  caixa: {
    backgroundColor: cores.rosaCampo,
    borderRadius: raio.pill,
    paddingHorizontal: 18,
    minHeight: 46,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  textoCaixa: { fontSize: 15, color: cores.texto, flex: 1 },
  placeholder: { color: cores.placeholder },
  fundo: {
    flex: 1,
    backgroundColor: 'rgba(74,29,54,0.45)',
    justifyContent: 'center',
    padding: 30,
  },
  janela: {
    backgroundColor: cores.branco,
    borderRadius: raio.cartao + 6,
    padding: 18,
    maxHeight: '60%',
  },
  tituloJanela: {
    fontSize: 17,
    fontWeight: 'bold',
    color: cores.rosaTitulo,
    marginBottom: 10,
    textAlign: 'center',
  },
  opcao: {
    paddingVertical: 13,
    paddingHorizontal: 14,
    borderRadius: raio.pill,
  },
  opcaoAtiva: { backgroundColor: cores.rosaClaro },
  textoOpcao: { fontSize: 15, color: cores.texto, textAlign: 'center' },
  textoOpcaoAtiva: { fontWeight: 'bold', color: cores.rosa },
});
