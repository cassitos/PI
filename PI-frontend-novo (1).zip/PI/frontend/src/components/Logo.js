import { Image } from 'react-native';

const PROPORCAO = 520 / 330;

export default function Logo({ largura = 150, estilo }) {
  return (
    <Image
      source={require('../img/logo-connected-woman.png')}
      accessibilityLabel="Connected Woman"
      resizeMode="contain"
      style={[{ width: largura, height: largura / PROPORCAO }, estilo]}
    />
  );
}
