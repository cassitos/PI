import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Abby from '../components/Abby';
import Campo from '../components/Campo';
import Botao from '../components/Botao';
import { avisar } from '../utils/avisar';
import { login } from '../services/api';
import { cores, raio } from '../theme';

const ROTULO_PERFIL = {
  doadora: 'doadora',
  beneficiaria: 'beneficiária',
  instituicao: 'instituição',
  admin: 'administradora',
};

export default function LoginScreen({ onEntrar, navigation }) {
  const margem = useSafeAreaInsets();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [entrando, setEntrando] = useState(false);
  // quando o mesmo e-mail tem mais de um perfil (doadora e beneficiária), a pessoa escolhe
  const [perfis, setPerfis] = useState(null);

  async function entrar() {
    if (!email || !senha) {
      avisar('Atenção', 'Preencha o e-mail e a senha.');
      return;
    }
    setEntrando(true);
    try {
      const resposta = await login(email, senha);
      const lista = resposta.perfis && resposta.perfis.length > 0 ? resposta.perfis : [resposta.usuario];
      if (lista.length > 1) {
        setPerfis(lista);
      } else {
        onEntrar(lista[0]);
      }
    } catch (erro) {
      avisar('Não foi possível entrar', erro.message);
    } finally {
      setEntrando(false);
    }
  }

  function esqueceuSenha() {
    avisar('Esqueceu a senha?', 'Enviaremos um link de recuperação para o seu e-mail.');
  }

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={estilos.fundo}>
      <ScrollView
        contentContainerStyle={[estilos.conteudo, { paddingTop: margem.top + 12, paddingBottom: margem.bottom + 24 }]}
        keyboardShouldPersistTaps="handled"
      >
        <TouchableOpacity
          style={estilos.voltar}
          onPress={() => (navigation.canGoBack() ? navigation.goBack() : null)}
          accessibilityLabel="Voltar"
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="arrow-back" size={24} color={cores.rosaTitulo} />
        </TouchableOpacity>

        <View style={estilos.cartao}>
          <Text style={estilos.titulo}>Login</Text>
          <Abby pose="acena" altura={170} estilo={estilos.abby} />

          {perfis ? (
            <>
              <Text style={estilos.subtitulo}>Como você quer entrar?</Text>
              <Text style={estilos.dicaLogin}>
                Este e-mail tem mais de um perfil. Você pode trocar depois, no seu Perfil.
              </Text>
              {perfis.map((p) => (
                <Botao
                  key={p.id_usuario}
                  titulo={`Entrar como ${ROTULO_PERFIL[p.tipo] || p.tipo}`}
                  onPress={() => onEntrar(p)}
                  tipo="escuro"
                  estilo={{ marginTop: 12 }}
                />
              ))}
              <TouchableOpacity onPress={() => setPerfis(null)} style={estilos.linkVoltar}>
                <Text style={estilos.voltarTexto}>Voltar</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <View style={estilos.form}>
                <Campo
                  rotulo="E-mail"
                  valor={email}
                  aoMudar={setEmail}
                  placeholder="E-mail"
                  tipoTeclado="email-address"
                  icone="mail"
                  semRotulo
                  sobreRosa
                />
                <Campo
                  rotulo="Senha"
                  valor={senha}
                  aoMudar={setSenha}
                  placeholder="Senha"
                  senha
                  semRotulo
                  sobreRosa
                />
              </View>

              <TouchableOpacity onPress={esqueceuSenha}>
                <Text style={estilos.esqueceu}>Esqueceu a senha?</Text>
              </TouchableOpacity>

              {/* o tipo da conta (doadora, beneficiária, instituição ou admin) é reconhecido pelo e-mail */}
              <Botao
                titulo={entrando ? 'Entrando...' : 'Entrar'}
                tipo="escuro"
                onPress={entrar}
                estilo={estilos.botaoEntrar}
              />
              <Text style={estilos.dicaLogin}>
                Doadoras, beneficiárias e instituições entram por aqui.
              </Text>
            </>
          )}
        </View>

        {!perfis && (
          <TouchableOpacity onPress={() => navigation.navigate('ComoContinuar')} style={estilos.linkCadastro}>
            <Text style={estilos.textoCadastro}>
              Não tem conta? <Text style={estilos.cadastreSe}>Cadastre-se</Text>
            </Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const estilos = StyleSheet.create({
  fundo: { flex: 1, backgroundColor: cores.rosaFundo },
  conteudo: { flexGrow: 1, paddingHorizontal: 24 },
  voltar: { alignSelf: 'flex-start', padding: 4, marginBottom: 6 },
  cartao: {
    backgroundColor: cores.rosaForte,
    borderRadius: raio.bloco,
    paddingHorizontal: 26,
    paddingTop: 18,
    paddingBottom: 28,
  },
  titulo: { fontSize: 26, color: cores.rosaTitulo, textAlign: 'center', fontWeight: '600' },
  abby: { alignSelf: 'center', marginTop: 6, marginBottom: 14 },
  subtitulo: { fontSize: 17, fontWeight: 'bold', color: cores.branco, textAlign: 'center' },
  form: { marginTop: 4 },
  esqueceu: {
    color: cores.branco,
    textAlign: 'right',
    marginBottom: 18,
    marginTop: -4,
    marginRight: 10,
    fontWeight: '600',
    fontSize: 13,
  },
  botaoEntrar: { alignSelf: 'center', paddingHorizontal: 48 },
  dicaLogin: { fontSize: 12, color: cores.branco, textAlign: 'center', marginTop: 12 },
  linkVoltar: { marginTop: 16, alignItems: 'center' },
  voltarTexto: { color: cores.branco, fontWeight: 'bold', fontSize: 14 },
  linkCadastro: { marginTop: 22, alignItems: 'center' },
  textoCadastro: { color: cores.textoClaro, fontSize: 14 },
  cadastreSe: { color: cores.rosaEscuro, fontWeight: 'bold' },
});
