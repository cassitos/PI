import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Abby from '../components/Abby';
import Logo from '../components/Logo';
import Botao from '../components/Botao';
import { cores, raio } from '../theme';

// Primeira tela do protótipo: "Seja bem-vinda"
export default function BoasVindasScreen({ navigation }) {
  const margem = useSafeAreaInsets();

  return (
    <View style={estilos.tela}>
      <ScrollView
        style={estilos.topo}
        contentContainerStyle={[estilos.topoConteudo, { paddingTop: margem.top + 24 }]}
        bounces={false}
      >
        <View style={estilos.marca}>
          <Abby altura={240} />
          <Logo largura={130} estilo={estilos.logo} />
        </View>
      </ScrollView>

      <View style={[estilos.cartao, { paddingBottom: margem.bottom + 28 }]}>
        <Text style={estilos.titulo}>Seja bem-vinda</Text>
        <Text style={estilos.texto}>
          Aqui é um espaço seguro para conectar, e transformar realidades. Connected Woman,
          mulheres ajudando mulheres.
        </Text>

        <View style={estilos.botoes}>
          <Botao
            titulo="Cadastro"
            tipo="escuro"
            onPress={() => navigation.navigate('ComoContinuar')}
            estilo={estilos.botao}
          />
          <Botao
            titulo="Fazer login"
            tipo="claro"
            onPress={() => navigation.navigate('Login')}
            estilo={estilos.botao}
          />
        </View>
      </View>
    </View>
  );
}

const estilos = StyleSheet.create({
  tela: { flex: 1, backgroundColor: cores.branco },
  topo: { flex: 1 },
  topoConteudo: { flexGrow: 1, justifyContent: 'center', paddingHorizontal: 20, paddingBottom: 16 },
  marca: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  logo: { marginLeft: -6 },
  cartao: {
    backgroundColor: cores.rosaForte,
    borderTopLeftRadius: raio.bloco,
    borderTopRightRadius: raio.bloco,
    paddingHorizontal: 28,
    paddingTop: 28,
  },
  titulo: { fontSize: 24, fontWeight: 'bold', color: cores.branco, marginBottom: 8 },
  texto: { fontSize: 14, color: cores.branco, lineHeight: 20, marginBottom: 24 },
  botoes: { flexDirection: 'row', gap: 14, justifyContent: 'center' },
  botao: { flex: 1, maxWidth: 170 },
});
