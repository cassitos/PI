import { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Abby from "../components/Abby";
import Campo from "../components/Campo";
import Seletor from "../components/Seletor";
import Botao from "../components/Botao";
import { avisar } from "../utils/avisar";
import { cadastrarDoadora, cadastrarBeneficiaria, cadastrarInstituicao, login } from "../services/api";
import { cores, raio } from "../theme";

const CIDADES = [
  "Porto Alegre",
  "Canoas",
  "São Leopoldo",
  "Novo Hamburgo",
  "Gravataí",
  "Sapucaia do Sul",
  "Esteio",
  "Viamão",
];
const FREQUENCIAS = [
  "Semanalmente",
  "Quinzenalmente",
  "Mensalmente",
  "Quando possível",
];
const NECESSIDADES = [
  "Absorventes",
  "Coletor menstrual",
  "Calcinha absorvente",
  "Itens de higiene",
  "Outro",
];

export default function CadastroScreen({ onEntrar, navigation, route }) {
  const margem = useSafeAreaInsets();
  const [perfil, setPerfil] = useState(route?.params?.perfil || "doadora");

  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");
  const [telefone, setTelefone] = useState("");
  const [cidade, setCidade] = useState("");
  const [frequencia, setFrequencia] = useState("");
  const [necessidade, setNecessidade] = useState("");
  const [salvando, setSalvando] = useState(false);

  const ehDoadora = perfil === "doadora";
  const ehInstituicao = perfil === "instituicao";

  async function cadastrar() {
    if (!nome) {
      avisar("Atenção", ehInstituicao ? "Preencha o nome da instituição." : "Por favor, preencha o seu nome completo.");
      return;
    }
    if (!email || !senha) {
      avisar("Atenção", "Preencha o e-mail e a senha para criar seu acesso.");
      return;
    }

    if (senha !== confirmarSenha) {
      avisar("Atenção", "As senhas não são iguais. Confira e tente de novo.");
      return;
    }

    setSalvando(true);
    try {
      if (ehInstituicao) {
        await cadastrarInstituicao({ nome, email, telefone, cidade, senha });
      } else if (ehDoadora) {
        await cadastrarDoadora({ nome, email, telefone, cidade, frequencia, senha });
      } else {
        await cadastrarBeneficiaria({ nome, email, telefone, cidade, necessidade, senha });
      }

      const resposta = await login(email, senha);
      // entra no perfil que acabou de criar (o e-mail pode ter outro perfil mais antigo)
      const criado = (resposta.perfis || []).find((p) => p.tipo === perfil) || resposta.usuario;
      avisar("Cadastro concluído!", `Seja bem-vinda, ${nome}!`);
      onEntrar(criado);
    } catch (erro) {
      avisar("Não foi possível cadastrar", erro.message);
    } finally {
      setSalvando(false);
    }
  }

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={estilos.tela}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: margem.bottom + 28 }}
        keyboardShouldPersistTaps="handled"
      >
        <View style={[estilos.cabecalho, { paddingTop: margem.top + 10 }]}>
          <TouchableOpacity
            style={[estilos.voltar, { top: margem.top + 10 }]}
            onPress={() => (navigation.canGoBack() ? navigation.goBack() : null)}
            accessibilityLabel="Voltar"
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Ionicons name="arrow-back" size={24} color={cores.branco} />
          </TouchableOpacity>
          <Text style={estilos.tituloTela}>Cadastro</Text>
          <Abby pose="chave" altura={200} estilo={estilos.abby} />
        </View>

        <View style={estilos.corpo}>
          <View style={estilos.abas}>
            <TouchableOpacity
              style={[estilos.aba, ehDoadora && estilos.abaAtiva]}
              onPress={() => setPerfil("doadora")}
            >
              <Ionicons name="heart" size={15} color={ehDoadora ? cores.branco : cores.rosaTitulo} />
              <Text style={[estilos.abaTexto, ehDoadora && estilos.abaTextoAtivo]}>Quero doar</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[estilos.aba, perfil === "beneficiaria" && estilos.abaAtiva]}
              onPress={() => setPerfil("beneficiaria")}
            >
              <Ionicons
                name="hand-left"
                size={15}
                color={perfil === "beneficiaria" ? cores.branco : cores.rosaTitulo}
              />
              <Text style={[estilos.abaTexto, perfil === "beneficiaria" && estilos.abaTextoAtivo]}>
                Preciso de ajuda
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[estilos.aba, ehInstituicao && estilos.abaAtiva]}
              onPress={() => setPerfil("instituicao")}
            >
              <Ionicons name="business" size={15} color={ehInstituicao ? cores.branco : cores.rosaTitulo} />
              <Text style={[estilos.abaTexto, ehInstituicao && estilos.abaTextoAtivo]}>Sou instituição</Text>
            </TouchableOpacity>
          </View>

          <Text style={estilos.titulo}>
            {ehInstituicao
              ? "Cadastro de Instituição"
              : ehDoadora
              ? "Cadastro de Doadora"
              : "Cadastro de Beneficiária"}
          </Text>
          <Text style={estilos.descricao}>
            {ehInstituicao
              ? "Cadastre a sua instituição para indicar pontos de coleta. Cada ponto novo passa por uma aprovação da nossa equipe antes de aparecer no mapa."
              : ehDoadora
              ? "Sua doação pode transformar a vida de uma mulher. Preencha os dados abaixo para começar a fazer a diferença."
              : "Você não está sozinha. Preencha os dados abaixo e conectaremos você com uma doadora na sua região."}
          </Text>

          <Campo
            rotulo={ehInstituicao ? "Nome da instituição" : "Nome completo"}
            valor={nome}
            aoMudar={setNome}
            placeholder={ehInstituicao ? "Nome da instituição" : "Nome completo"}
            icone="person"
            semRotulo
          />
          <Campo
            rotulo="E-mail"
            valor={email}
            aoMudar={setEmail}
            placeholder="E-mail"
            tipoTeclado="email-address"
            icone="mail"
            semRotulo
          />
          <Campo
            rotulo="Senha"
            valor={senha}
            aoMudar={setSenha}
            placeholder="Senha"
            senha
            semRotulo
          />
          <Campo
            rotulo="Confirmar senha"
            valor={confirmarSenha}
            aoMudar={setConfirmarSenha}
            placeholder="Confirmar senha"
            senha
            semRotulo
          />
          <Campo
            rotulo="Telefone"
            valor={telefone}
            aoMudar={setTelefone}
            placeholder="Telefone"
            tipoTeclado="phone-pad"
            icone="call"
            semRotulo
          />
          <Seletor
            rotulo="Cidade"
            valor={cidade}
            aoEscolher={setCidade}
            opcoes={CIDADES}
            placeholder="Cidade"
            semRotulo
          />

          {ehInstituicao ? null : ehDoadora ? (
            <Seletor
              rotulo="Frequência de doação"
              valor={frequencia}
              aoEscolher={setFrequencia}
              opcoes={FREQUENCIAS}
              placeholder="Frequência de doação"
              semRotulo
            />
          ) : (
            <Seletor
              rotulo="Tipo de necessidade"
              valor={necessidade}
              aoEscolher={setNecessidade}
              opcoes={NECESSIDADES}
              placeholder="Tipo de necessidade"
              semRotulo
            />
          )}

          <Botao
            titulo={salvando ? "Cadastrando..." : "Cadastrar"}
            onPress={cadastrar}
            estilo={estilos.botao}
          />

          <TouchableOpacity onPress={() => navigation.navigate("Login")} style={estilos.jaTenho}>
            <Text style={estilos.jaTenhoTexto}>
              Já tem conta? <Text style={estilos.jaTenhoLink}>Fazer login</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const estilos = StyleSheet.create({
  tela: { flex: 1, backgroundColor: cores.rosaCorpo },
  cabecalho: {
    backgroundColor: cores.rosaForte,
    borderBottomLeftRadius: raio.bloco,
    borderBottomRightRadius: raio.bloco,
    alignItems: "center",
    paddingBottom: 18,
  },
  voltar: { position: "absolute", left: 18, zIndex: 2, padding: 4 },
  tituloTela: { fontSize: 28, color: cores.rosaTitulo, fontWeight: "600", marginBottom: 6 },
  abby: { alignSelf: "center" },
  corpo: { paddingHorizontal: 26, paddingTop: 22 },
  abas: {
    flexDirection: "row",
    backgroundColor: "rgba(255,255,255,0.55)",
    borderRadius: raio.pill,
    padding: 4,
    marginBottom: 20,
  },
  aba: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
    paddingVertical: 10,
    borderRadius: raio.pill,
  },
  abaAtiva: { backgroundColor: cores.rosa },
  abaTexto: { color: cores.rosaTitulo, fontWeight: "600", fontSize: 12 },
  abaTextoAtivo: { color: cores.branco },
  titulo: {
    fontSize: 19,
    fontWeight: "bold",
    color: cores.rosaTitulo,
    marginBottom: 6,
    textAlign: "center",
  },
  descricao: {
    fontSize: 13,
    color: cores.texto,
    marginBottom: 20,
    lineHeight: 19,
    textAlign: "center",
  },
  botao: { alignSelf: "center", paddingHorizontal: 56, marginTop: 10 },
  jaTenho: { alignItems: "center", marginTop: 18 },
  jaTenhoTexto: { color: cores.textoClaro, fontSize: 14 },
  jaTenhoLink: { color: cores.rosaEscuro, fontWeight: "bold" },
});
