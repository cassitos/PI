import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Abby from '../components/Abby';
import Botao from '../components/Botao';
import { cores, raio, sombra } from '../theme';

// Segunda tela do protótipo: "Como deseja continuar?"
// Cada opção abre o cadastro já no perfil escolhido.
export default function ComoContinuarScreen({ navigation }) {
  const margem = useSafeAreaInsets();

  function continuar(perfil) {
    navigation.navigate('Cadastro', { perfil });
  }

  return (
    <ScrollView
      style={estilos.tela}
      contentContainerStyle={[estilos.conteudo, { paddingTop: margem.top + 12, paddingBottom: margem.bottom + 24 }]}
    >
      <TouchableOpacity
        style={estilos.voltar}
        onPress={() => navigation.goBack()}
        accessibilityLabel="Voltar"
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons name="arrow-back" size={24} color={cores.rosaTitulo} />
      </TouchableOpacity>

      <Abby pose="aponta" altura={190} estilo={estilos.abby} />
      <Text style={estilos.titulo}>Como deseja continuar?</Text>

      <Opcao
        titulo="Quero ajudar"
        descricao="Ajude mulheres em situação de vulnerabilidade doando itens de higiene menstrual."
        onPress={() => continuar('doadora')}
      />
      <Opcao
        titulo="Preciso de ajuda"
        descricao="Solicite doações de forma simples e encontre pontos de apoio perto de você!"
        onPress={() => continuar('beneficiaria')}
      />

      <TouchableOpacity style={estilos.instituicao} onPress={() => continuar('instituicao')}>
        <Ionicons name="business-outline" size={18} color={cores.rosaTitulo} />
        <Text style={estilos.instituicaoTexto}>Sou uma instituição</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Login')} style={estilos.jaTenho}>
        <Text style={estilos.jaTenhoTexto}>
          Já tem conta? <Text style={estilos.jaTenhoLink}>Fazer login</Text>
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function Opcao({ titulo, descricao, onPress }) {
  return (
    <View style={estilos.cartao}>
      <View style={estilos.cartaoTopo}>
        <Text style={estilos.cartaoTitulo}>{titulo}</Text>
      </View>
      <Text style={estilos.cartaoTexto}>{descricao}</Text>
      <Botao titulo="Continuar" onPress={onPress} estilo={estilos.cartaoBotao} />
    </View>
  );
}

const estilos = StyleSheet.create({
  tela: { flex: 1, backgroundColor: cores.rosaFundo },
  conteudo: { paddingHorizontal: 24, alignItems: 'stretch' },
  voltar: { alignSelf: 'flex-start', padding: 4 },
  abby: { alignSelf: 'center' },
  titulo: {
    fontSize: 22,
    fontWeight: 'bold',
    color: cores.rosaTitulo,
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 18,
  },
  cartao: {
    backgroundColor: cores.branco,
    borderRadius: raio.cartao,
    padding: 12,
    marginBottom: 16,
    ...sombra,
  },
  cartaoTopo: {
    backgroundColor: cores.rosaMedio,
    borderRadius: raio.cartao - 6,
    paddingVertical: 14,
    alignItems: 'center',
  },
  cartaoTitulo: { fontSize: 20, fontWeight: 'bold', color: cores.branco },
  cartaoTexto: {
    fontSize: 14,
    color: cores.texto,
    lineHeight: 20,
    paddingHorizontal: 8,
    paddingVertical: 14,
  },
  cartaoBotao: { alignSelf: 'center', paddingVertical: 9, paddingHorizontal: 34 },
  instituicao: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: raio.pill,
    borderWidth: 1.5,
    borderColor: cores.rosaTitulo,
    marginTop: 2,
  },
  instituicaoTexto: { color: cores.rosaTitulo, fontWeight: '600', fontSize: 14 },
  jaTenho: { alignItems: 'center', marginTop: 18 },
  jaTenhoTexto: { color: cores.textoClaro, fontSize: 14 },
  jaTenhoLink: { color: cores.rosaEscuro, fontWeight: 'bold' },
});
